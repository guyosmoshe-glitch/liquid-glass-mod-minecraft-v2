package dev.guyos.reflections;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReflectionsClient implements ClientModInitializer {
    public static final String MOD_ID = "guyos_reflections";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        try {
            ReflectionsConfig.load();
            LOGGER.info("GUYOS Reflections stage 1 loaded. Backend: {}. Sodium present: {}. No rendering hooks installed.",
                    detectBackend(), FabricLoader.getInstance().isModLoaded("sodium"));
        } catch (Throwable t) {
            // Never let this mod stop the game from starting.
            LOGGER.error("GUYOS Reflections failed to initialise; continuing without it", t);
        }
    }

    /** Best-effort, log-only. Uses no Minecraft or Sodium internals, so it cannot break on version changes. */
    public static String detectBackend() {
        try {
            String prop = System.getProperty("org.lwjgl.vulkan.libname");
            if (prop != null) return "Vulkan (system property)";
            Class.forName("org.lwjgl.vulkan.VK");
            return "Vulkan classes present (active backend not confirmed)";
        } catch (Throwable t) {
            return "unknown";
        }
    }
}
