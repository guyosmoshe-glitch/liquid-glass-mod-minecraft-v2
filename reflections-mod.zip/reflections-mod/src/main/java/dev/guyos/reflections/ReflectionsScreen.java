package dev.guyos.reflections;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.IntConsumer;

/**
 * Apple-inspired settings screen: dark rounded card, tab bar, animated iOS-style switches, sliders, tooltips,
 * and an approximate live preview. Built from stable vanilla widgets (Button, AbstractSliderButton, Tooltip)
 * plus plain GuiGraphics.fill drawing. No custom render pipeline, so it cannot interfere with Sodium.
 *
 * NOTE (unverified against 26.3): if the compiler rejects extractBackground, extractRenderState, text, fill and gui.setScreen,
 * those are the only places that depend on the GuiGraphics API. See README.
 */
public class ReflectionsScreen extends Screen {
    private static final String[] TABS = {"General", "Effects", "Quality", "Advanced"};
    private static int currentTab = 0;

    // Palette (ARGB)
    private static final int BG = 0xE60B0B0E;
    private static final int CARD = 0xFF1C1C1E;
    private static final int ROW = 0xFF2C2C2E;
    private static final int ROW_HOVER = 0xFF3A3A3C;
    private static final int TEXT = 0xFFFFFFFF;
    private static final int TEXT_DIM = 0xFF8E8E93;
    private static final int GREEN = 0xFF34C759;
    private static final int BLUE = 0xFF0A84FF;
    private static final int OFF = 0xFF48484A;

    private static final int CARD_W = 400;
    private static final int CONTENT_W = 216;
    private static final int ROW_H = 20;
    private static final int ROW_GAP = 26;
    private static final int TOP = 66;

    private final Screen parent;
    private final ReflectionsConfig cfg = ReflectionsConfig.get();

    private record ToggleRow(String label, BooleanSupplier value, int y, int id) {}
    private final List<ToggleRow> toggles = new ArrayList<>();
    private final float[] anim = new float[16];
    private boolean animInit = false;

    public ReflectionsScreen(Screen parent) {
        super(Component.literal("Reflections"));
        this.parent = parent;
    }

    // ---------------------------------------------------------------- layout

    private int left() { return this.width / 2 - CARD_W / 2; }

    @Override
    protected void init() {
        toggles.clear();
        int x = left() + 12;

        for (int t = 0; t < TABS.length; t++) {
            final int tab = t;
            addRenderableWidget(Button.builder(Component.literal(TABS[t]), b -> { currentTab = tab; rebuildWidgets(); })
                    .bounds(x + t * 55, 36, 51, 18).build());
        }

        int row = 0;
        switch (currentTab) {
            case 0 -> {
                addToggle("Reflections", "Master switch. Off disables every effect from this mod.",
                        () -> cfg.enabled, () -> cfg.enabled = !cfg.enabled, row++);
                addToggle("Interface animations", "Animate switches in this screen. Turn off for instant changes.",
                        () -> cfg.uiAnimations, () -> cfg.uiAnimations = !cfg.uiAnimations, row++);
                addToggle("Live preview", "Show the approximate preview panel. It is a 2D mock-up, not the real in-game render.",
                        () -> cfg.livePreview, () -> cfg.livePreview = !cfg.livePreview, row++);
                Button preset = Button.builder(Component.literal("Preset: " + cfg.preset), b -> {
                            ReflectionsConfig.Preset[] all = ReflectionsConfig.Preset.values();
                            cfg.applyPreset(all[(cfg.preset.ordinal() + 1) % all.length]);
                            rebuildWidgets();
                        })
                        .bounds(x, TOP + ROW_GAP * row++, CONTENT_W, ROW_H)
                        .tooltip(Tooltip.create(Component.literal("Performance: low resolution, short range. Balanced: default. Quality: full resolution, long range. Changing any slider afterwards keeps your custom value.")))
                        .build();
                addRenderableWidget(preset);
            }
            case 1 -> {
                addToggle("Water reflections", "Reflect the sky and nearby terrain on water surfaces.",
                        () -> cfg.waterReflections, () -> cfg.waterReflections = !cfg.waterReflections, row++);
                addToggle("Ground reflections", "Reflect on wet or glossy ground surfaces.",
                        () -> cfg.groundReflections, () -> cfg.groundReflections = !cfg.groundReflections, row++);
                addToggle("Block reflections", "Reflect on suitable polished blocks such as glass, ice and metal.",
                        () -> cfg.blockReflections, () -> cfg.blockReflections = !cfg.blockReflections, row++);
                addToggle("Denoise", "Smooth grain in reflections. Slightly softer result, small cost.",
                        () -> cfg.denoise, () -> cfg.denoise = !cfg.denoise, row++);
            }
            case 2 -> {
                addSlider("Intensity", "%", 0, 100, cfg.intensity, v -> cfg.intensity = v, row++,
                        "Overall strength of reflections.");
                addSlider("Reflectivity", "%", 0, 100, cfg.reflectivity, v -> cfg.reflectivity = v, row++,
                        "How mirror-like surfaces are.");
                addSlider("Roughness", "%", 0, 100, cfg.roughness, v -> cfg.roughness = v, row++,
                        "Higher values blur reflections as on rough surfaces. Lower is sharper.");
                addSlider("Temporal smoothing", "%", 0, 100, cfg.temporalSmoothing, v -> cfg.temporalSmoothing = v, row++,
                        "Blends frames to reduce flicker. Too high can cause ghosting while moving.");
            }
            case 3 -> {
                addSlider("Reflection distance", " blocks", 16, 512, cfg.reflectionDistance, v -> cfg.reflectionDistance = v, row++,
                        "How far the effect searches for something to reflect. Longer costs more performance.");
                addSlider("Fade distance", " blocks", 16, 256, cfg.fadeDistance, v -> cfg.fadeDistance = v, row++,
                        "Distance over which reflections fade out smoothly.");
                addSlider("Resolution", "%", 25, 100, cfg.resolutionPercent, v -> cfg.resolutionPercent = v, row++,
                        "Reflection buffer size relative to the screen. Lower is faster.");
            }
            default -> { }
        }

        int by = TOP + ROW_GAP * 5 + 4;
        addRenderableWidget(Button.builder(Component.literal("Reset to defaults"), b -> {
                    cfg.resetToDefaults();
                    rebuildWidgets();
                })
                .bounds(x, by, 104, ROW_H)
                .tooltip(Tooltip.create(Component.literal("Restore every setting to its default value.")))
                .build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(x + 112, by, 104, ROW_H)
                .tooltip(Tooltip.create(Component.literal("Save and close.")))
                .build());
    }

    private void addToggle(String label, String tip, BooleanSupplier value, Runnable flip, int row) {
        int id = toggles.size();
        int y = TOP + ROW_GAP * row;
        toggles.add(new ToggleRow(label, value, y, id));
        // Invisible-by-overdraw button spanning the whole row: gives click handling + tooltip.
        addRenderableWidget(Button.builder(Component.empty(), b -> flip.run())
                .bounds(left() + 12, y, CONTENT_W, ROW_H)
                .tooltip(Tooltip.create(Component.literal(tip)))
                .build());
    }

    private void addSlider(String label, String suffix, int min, int max, int cur, IntConsumer setter, int row, String tip) {
        IntSlider s = new IntSlider(left() + 12, TOP + ROW_GAP * row, CONTENT_W, ROW_H, label, suffix, min, max, cur, setter);
        s.setTooltip(Tooltip.create(Component.literal(tip)));
        addRenderableWidget(s);
    }

    private static final class IntSlider extends AbstractSliderButton {
        private final String label, suffix;
        private final int min, max;
        private final IntConsumer setter;

        IntSlider(int x, int y, int w, int h, String label, String suffix, int min, int max, int cur, IntConsumer setter) {
            super(x, y, w, h, Component.empty(), (cur - min) / (double) (max - min));
            this.label = label;
            this.suffix = suffix;
            this.min = min;
            this.max = max;
            this.setter = setter;
            updateMessage();
        }

        private int current() {
            return min + (int) Math.round(this.value * (max - min));
        }

        @Override
        protected void updateMessage() {
            if (label == null) return; // called before fields are set
            setMessage(Component.literal(label + ": " + current() + suffix));
        }

        @Override
        protected void applyValue() {
            setter.accept(current());
        }
    }

    // ---------------------------------------------------------------- drawing

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, this.width, this.height, BG);
        int l = left();
        roundRect(g, l, 14, l + CARD_W, TOP + ROW_GAP * 5 + 34, 6, CARD);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(g, mouseX, mouseY, partialTick);

        int l = left();
        int x = l + 12;
        g.text(this.font, Component.literal("Reflections").withStyle(ChatFormatting.BOLD), x, 20, TEXT, false);
        g.text(this.font, Component.literal("Stage 1: settings only, effects not rendered yet"), x + 70, 21, TEXT_DIM, false);

        // Active tab underline
        g.fill(x + currentTab * 55 + 4, 56, x + currentTab * 55 + 47, 58, BLUE);

        // Switch rows drawn over their invisible buttons
        for (ToggleRow t : toggles) {
            boolean on = t.value().getAsBoolean();
            float target = on ? 1f : 0f;
            if (t.id() < anim.length) {
                if (!animInit || !cfg.uiAnimations) anim[t.id()] = target;
                else anim[t.id()] += (target - anim[t.id()]) * 0.3f;
            }
            float p = t.id() < anim.length ? anim[t.id()] : target;

            boolean hover = mouseX >= x && mouseX < x + CONTENT_W && mouseY >= t.y() && mouseY < t.y() + ROW_H;
            roundRect(g, x, t.y(), x + CONTENT_W, t.y() + ROW_H, 4, hover ? ROW_HOVER : ROW);
            g.text(this.font, Component.literal(t.label()), x + 8, t.y() + 6, TEXT, false);

            int px = x + CONTENT_W - 36, py = t.y() + 3, pw = 28, ph = 14;
            roundRect(g, px, py, px + pw, py + ph, ph / 2, lerpColor(OFF, GREEN, p));
            int kx = px + 1 + Math.round(p * (pw - ph));
            roundRect(g, kx, py + 1, kx + ph - 2, py + ph - 1, (ph - 2) / 2, TEXT);
        }
        animInit = true;

        if (cfg.livePreview) drawPreview(g, l + 250, 66, 138, 104);
    }

    /** Approximate 2D mock-up driven by the current settings. NOT the in-game render. */
    private void drawPreview(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        roundRect(g, x, y, x + w, y + h, 5, ROW);
        int ix = x + 6, iy = y + 6, iw = w - 12, ih = h - 24;
        int horizon = iy + ih / 2;

        // Sky gradient
        for (int r = 0; r < ih / 2; r++) {
            float t = r / (float) (ih / 2);
            g.fill(ix, iy + r, ix + iw, iy + r + 1, lerpColor(0xFF3B82F6, 0xFFBFDBFE, t));
        }
        // Water base
        g.fill(ix, horizon, ix + iw, iy + ih, 0xFF0B3A66);

        // Object (a tower) above horizon
        int tw = 14, th = ih / 2 - 10, tx = ix + iw / 2 - tw / 2;
        g.fill(tx, horizon - th, tx + tw, horizon, 0xFFE5E7EB);

        // Reflection below horizon: alpha from intensity * reflectivity, fades with distance, widens with roughness
        float strength = cfg.enabled && cfg.waterReflections ? (cfg.intensity / 100f) * (0.3f + 0.7f * cfg.reflectivity / 100f) : 0f;
        int blur = Math.round(cfg.roughness / 100f * 4f);
        float reach = Math.max(0.15f, Math.min(1f, cfg.fadeDistance / 256f + 0.2f));
        int rows = Math.min(th, ih / 2 - 2);
        for (int r = 0; r < rows; r++) {
            float fade = 1f - (r / (float) rows) / reach;
            if (fade <= 0f) break;
            int a = Math.round(255f * strength * 0.8f * fade);
            int col = (Math.max(0, Math.min(255, a)) << 24) | 0xE5E7EB;
            g.fill(tx - blur, horizon + r, tx + tw + blur, horizon + r + 1, col);
        }

        g.text(this.font, Component.literal("Approximate preview"), x + 6, y + h - 14, TEXT_DIM, false);
    }

    private static void roundRect(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int r, int color) {
        int h = y2 - y1;
        r = Math.max(0, Math.min(r, Math.min(h, x2 - x1) / 2));
        for (int row = 0; row < h; row++) {
            int d = row < r ? r - row : (row >= h - r ? row - (h - r - 1) : 0);
            int inset = 0;
            if (d > 0) {
                double dy = d - 0.5;
                inset = r - (int) Math.floor(Math.sqrt(Math.max(0.0, (double) r * r - dy * dy)));
            }
            g.fill(x1 + inset, y1 + row, x2 - inset, y1 + row + 1, color);
        }
    }

    private static int lerpColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int r = Math.round(ar + (br - ar) * t), gg = Math.round(ag + (bg - ag) * t), bl = Math.round(ab + (bb - ab) * t);
        return 0xFF000000 | (r << 16) | (gg << 8) | bl;
    }

    @Override
    public void onClose() {
        ReflectionsConfig.save();
        Minecraft.getInstance().gui.setScreen(parent);
    }
}
