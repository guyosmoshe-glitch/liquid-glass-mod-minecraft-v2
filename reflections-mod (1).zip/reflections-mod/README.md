# GUYOS Reflections: Stage 1 (safe skeleton)

Target: Minecraft 26.3, Fabric Loader 0.20.1, Java 25, Prism Launcher.

## What this stage is
- Client-only Fabric mod with **no mixins and no rendering hooks**, so it can't interfere with Sodium, ImmediatelyFast or the Vulkan backend.
- Saves settings to `config/guyos_reflections.json` (persists across restarts).
- Settings screen opens from Mod Menu (uses only vanilla widgets, no Cloth/YACL dependency).
- Logs the detected backend and whether Sodium is present.
- **It does not draw any reflections yet.** Settings are stored for stage 2.

## Interface (v0.1.1)
Four tabs (General, Effects, Quality, Advanced), animated iOS-style switches, sliders, tooltips on every setting,
presets, reset to defaults, and an approximate live preview (a 2D mock-up, not the real render).
If the build fails, the likeliest spots are the GuiGraphics calls in `ReflectionsScreen.java`
(`renderBackground`, `render`, `drawString`, `fill`). Those are the only files that touch the drawing API.

## Verification status
- Compiled: NO (the build sandbox could not reach Fabric's Maven or run Java 25).
- Launched in Minecraft: NO.
- Expect to fix a few API names on first build; send me the compiler output.

## Build (Windows, PowerShell, JDK 25 installed)
    cd reflections-mod
    gradle wrapper
    .\gradlew build

Jar: `build\libs\guyos-reflections-0.1.0.jar` (not the `-sources` one).

## Install (Prism Launcher)
1. Open Prism Launcher.
2. Select the existing Vulkan Optimization instance.
3. Open Edit.
4. Open Mods.
5. Select Add File.
6. Select the jar.
7. Launch Minecraft, then open Mod Menu > GUYOS Reflections.

Check `logs/latest.log` for the line starting "GUYOS Reflections stage 1 loaded".
