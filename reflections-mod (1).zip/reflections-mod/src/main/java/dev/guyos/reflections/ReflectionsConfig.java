package dev.guyos.reflections;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Plain JSON config stored in the Minecraft config folder. Survives restarts. Never throws. */
public final class ReflectionsConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String FILE_NAME = "guyos_reflections.json";

    // Master + effect toggles (stored now; they take effect once the render pass is added in stage 2)
    public boolean enabled = true;
    public boolean waterReflections = true;
    public boolean groundReflections = true;
    public boolean blockReflections = true;
    public boolean denoise = true;
    public boolean uiAnimations = true;
    public boolean livePreview = true;
    public boolean glassHud = true;
    public int glassOpacity = 30; // 0-100

    // Sliders, 0-100 unless noted
    public int intensity = 60;
    public int reflectivity = 50;
    public int roughness = 30;
    public int fadeDistance = 64;       // blocks, 16-256
    public int resolutionPercent = 50;  // 25-100
    public int temporalSmoothing = 40;
    public int reflectionDistance = 128; // blocks, 16-512

    public Preset preset = Preset.BALANCED;

    public enum Preset { PERFORMANCE, BALANCED, QUALITY }

    private static ReflectionsConfig instance = new ReflectionsConfig();

    public static ReflectionsConfig get() {
        return instance;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
    }

    public static void load() {
        Path p = path();
        if (!Files.exists(p)) {
            save();
            return;
        }
        try (Reader r = Files.newBufferedReader(p)) {
            ReflectionsConfig loaded = GSON.fromJson(r, ReflectionsConfig.class);
            if (loaded != null) {
                instance = loaded;
                instance.clamp();
            }
        } catch (Exception e) {
            ReflectionsClient.LOGGER.warn("Could not read config, using defaults", e);
            instance = new ReflectionsConfig();
        }
    }

    public static void save() {
        instance.clamp();
        try (Writer w = Files.newBufferedWriter(path())) {
            GSON.toJson(instance, w);
        } catch (IOException e) {
            ReflectionsClient.LOGGER.warn("Could not save config", e);
        }
    }

    public void resetToDefaults() {
        ReflectionsConfig d = new ReflectionsConfig();
        enabled = d.enabled;
        waterReflections = d.waterReflections;
        groundReflections = d.groundReflections;
        blockReflections = d.blockReflections;
        denoise = d.denoise;
        uiAnimations = d.uiAnimations;
        livePreview = d.livePreview;
        glassHud = d.glassHud;
        glassOpacity = d.glassOpacity;
        reflectionDistance = d.reflectionDistance;
        intensity = d.intensity;
        reflectivity = d.reflectivity;
        roughness = d.roughness;
        fadeDistance = d.fadeDistance;
        resolutionPercent = d.resolutionPercent;
        temporalSmoothing = d.temporalSmoothing;
        preset = d.preset;
    }

    public void applyPreset(Preset p) {
        preset = p;
        switch (p) {
            case PERFORMANCE -> { resolutionPercent = 25; fadeDistance = 32; reflectionDistance = 64; temporalSmoothing = 30; denoise = false; }
            case BALANCED    -> { resolutionPercent = 50; fadeDistance = 64; reflectionDistance = 128; temporalSmoothing = 40; denoise = true; }
            case QUALITY     -> { resolutionPercent = 100; fadeDistance = 128; reflectionDistance = 256; temporalSmoothing = 50; denoise = true; }
        }
    }

    private void clamp() {
        intensity = Math.max(0, Math.min(100, intensity));
        reflectivity = Math.max(0, Math.min(100, reflectivity));
        roughness = Math.max(0, Math.min(100, roughness));
        temporalSmoothing = Math.max(0, Math.min(100, temporalSmoothing));
        fadeDistance = Math.max(16, Math.min(256, fadeDistance));
        reflectionDistance = Math.max(16, Math.min(512, reflectionDistance));
        glassOpacity = Math.max(0, Math.min(100, glassOpacity));
        resolutionPercent = Math.max(25, Math.min(100, resolutionPercent));
        if (preset == null) preset = Preset.BALANCED;
    }
}
