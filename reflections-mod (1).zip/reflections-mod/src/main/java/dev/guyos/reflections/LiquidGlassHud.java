package dev.guyos.reflections;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

/** Adds one extra glass info panel (FPS and coordinates). Does not touch or replace any vanilla HUD element. */
public final class LiquidGlassHud {
    private LiquidGlassHud() {}

    public static void register() {
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(ReflectionsClient.MOD_ID, "glass_info"),
                LiquidGlassHud::extract);
    }

    private static void extract(GuiGraphicsExtractor g, DeltaTracker delta) {
        ReflectionsConfig cfg = ReflectionsConfig.get();
        if (!cfg.enabled || !cfg.glassHud) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        String l1 = "FPS  " + mc.getFps();
        String l2 = String.format("XYZ  %.0f  %.0f  %.0f", mc.player.getX(), mc.player.getY(), mc.player.getZ());

        int w = Math.max(mc.font.width(l1), mc.font.width(l2)) + 16;
        int h = 2 * 11 + 12;
        int x = 8, y = 8;

        Glass.panel(g, x, y, x + w, y + h, 6, cfg.glassOpacity);
        g.text(mc.font, Component.literal(l1), x + 8, y + 6, 0xFFFFFFFF, true);
        g.text(mc.font, Component.literal(l2), x + 8, y + 6 + 11, 0xFFD1D1D6, true);
    }
}
