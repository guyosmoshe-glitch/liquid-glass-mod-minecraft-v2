package dev.guyos.reflections;

import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Liquid-glass look built from plain translucent fills. No shaders, no render hooks, so it cannot conflict with Sodium or Vulkan. */
public final class Glass {
    private Glass() {}

    /** Frosted panel: bright rim, translucent dark body, soft top sheen. opacityPct is 0-100. */
    public static void panel(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int r, int opacityPct) {
        int a = Math.round(255f * Math.max(0, Math.min(100, opacityPct)) / 100f);
        int rim = (Math.min(255, 70 + a / 3) << 24) | 0xFFFFFF;
        int body = (a << 24) | 0x14141C;
        int sheen = (Math.min(255, 18 + a / 8) << 24) | 0xFFFFFF;

        roundRect(g, x1, y1, x2, y2, r, rim);
        roundRect(g, x1 + 1, y1 + 1, x2 - 1, y2 - 1, Math.max(0, r - 1), body);
        int mid = y1 + (y2 - y1) / 2;
        roundRect(g, x1 + 2, y1 + 2, x2 - 2, mid, Math.max(0, r - 2), sheen);
    }

    public static void roundRect(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int r, int color) {
        int h = y2 - y1;
        if (h <= 0 || x2 <= x1) return;
        r = Math.max(0, Math.min(r, Math.min(h, x2 - x1) / 2));
        for (int row = 0; row < h; row++) {
            int d = row < r ? r - row : (row >= h - r ? row - (h - r - 1) : 0);
            int inset = 0;
            if (d > 0) {
                double dy = d - 0.5;
                inset = r - (int) Math.floor(Math.sqrt(Math.max(0.0, (double) r * r - dy * dy)));
            }
            g.fill(x1 + inset, y1 + row, x2 - inset, y1 + row + 1, color);
        }
    }
}
